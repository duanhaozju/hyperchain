package tests

import (
	"path/filepath"
	"testing"
)

var (
	baseDir            = filepath.Join(".", "files")
	vmTestDir          = filepath.Join(baseDir, "VMTests")
	VmSkipTests    = []string{}
)

func TestVm(t *testing.T) {
	fn := filepath.Join(vmTestDir, "vmtests.json")
	if err := RunVmTest(fn, VmSkipTests); err != nil {
		t.Error(err)
	}
}
